import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class ColorButton extends JFrame implements MouseListener
{

	public JLabel label;

	public static void main(String args[]) 
	{
		new ColorButton();
	}

	ColorButton() 
	{
		label = new JLabel("No Mouse Event Captured", JLabel.CENTER);
		label.setOpaque(true);
		label.addMouseListener(this);

		add(label);

		setSize(200, 150);
		setTitle("Java Swing - JLabel Color On Hover");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}


	//Overridden Methods from MouseListener Interface
	//These methods are called automatically when corresponding mouse
	//event occurs 
	/////////////////////////////////////////////////
	public void mousePressed(MouseEvent e) 
	{
	   label.setText("Mouse Pressed");	   
	}
	
	public void mouseReleased(MouseEvent e)
	{
	    label.setText("Mouse Released");	    
	}
	
	public void mouseEntered(MouseEvent e) 
	{
	    label.setText("Mouse Entered");
   	    label.setBackground(Color.CYAN);
	}
	
	public void mouseExited(MouseEvent e) 
	{
	    label.setText("Mouse Exited");
	    label.setBackground(Color.WHITE);
	}
	
	public void mouseClicked(MouseEvent e) 
	{
	    label.setText("Mouse Clicked");
	}
}