import java.awt.*;

import java.awt.event.*;

import javax.swing.*;

import javax.swing.border.*;

 

public class Sodoku extends JFrame {

    private JFrame window = new JFrame("Sudoku");

    public Sodoku(){

        window.setSize(600,300);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setLayout(new GridLayout(1,2));

        Border lineBorder = new LineBorder(Color.BLACK,2);

        String[] game = { "Game","New", "Read", "Save", "Exit"};
       

        @SuppressWarnings("unchecked")
		JComboBox gameOptions = new JComboBox<Object>(game);

        gameOptions.setSelectedIndex(0);

         

        JPanel p2 = null;
        
        JPanel p1 =  new JPanel(new GridLayout(3,3));
        
        for (int k =0; k<9; k++)
        
        {
        
            p2 = new JPanel(new GridLayout(3,3));
        
         
        
            p2.setBorder(lineBorder);
        
            for(int i =0; i <=8; i++){
        
                p2.add(new JTextField(1));
        
            }
        
            for(int i = 0; i <=8; i++){
        
                p1.add(p2);

        }

      
                }
           

        JPanel Buttons = new JPanel(new GridLayout(5,1));


        Buttons.add(gameOptions);

         

        window.add(p1);

        window.add(Buttons);

        window.setVisible(true);

    }
    
    

    public static void main(String[] args){

        Sodoku Sud = new Sodoku();

    }

}
